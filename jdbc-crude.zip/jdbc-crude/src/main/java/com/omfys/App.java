package com.omfys;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
public class App {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(JdbcCrudeApplication.class);
		JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
		
		//Insert Operation
		String std_rollno="101";
		String std_name = "Charuli";
		float std_marks = 98.5f;
		
		String insert_query = "INSERT INTO Student VALUES (?,?,?)";
		int count = jdbcTemplate.update(insert_query,std_rollno, std_name,std_marks);
		
		if(count>0) 
			System.out.println("Insertion Successfull..!");
		else
			System.out.println("Insertion failed..!!");
		

	}

}
