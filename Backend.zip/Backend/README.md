# Online-Job-Portal
Spring Boot + Rest Controller + JPA with Hibernate Project for Online Job Portal
## Steps to Initialize the project
1. Download the source code using git.
2. Import the Project to your IDE.
3. Wait for the dependencies to be downloaded.
4. Update application.properties
5. Run the project as a spring boot application.

## Screenshots of the project
![Swagger UI](https://i.imgur.com/wC5vGiS.png)
