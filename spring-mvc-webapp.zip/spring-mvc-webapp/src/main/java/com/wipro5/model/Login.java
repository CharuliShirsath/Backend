package com.wipro5.model;

public class Login {
	
	private Double userid;
	private String uname;
	
	public Login() {
		
	}
	
	
	public Login(Double userid, String uname) {
		
		this.userid = userid;
		this.uname = uname;
	}


	public Double getUserid() {
		return userid;
	}


	public void setUserid(Double userid) {
		this.userid = userid;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	@Override
	public String toString() {
		return "Login [userid=" + userid + ", uname=" + uname + "]";
	}
	
	

}
