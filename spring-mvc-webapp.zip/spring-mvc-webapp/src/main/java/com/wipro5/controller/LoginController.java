package com.wipro5.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wipro5.model.Login;

@Controller
@RequestMapping("/lc")
public class LoginController {

    @PostMapping("/login")
    public String login(@ModelAttribute Login login, Model model) {
        // Your login logic here
        model.addAttribute("login", login);
        System.out.println(login);
        return "loginStatus";
    }

    @GetMapping("/loginForm")
    public String getLoginForm(Model model) {
        model.addAttribute("login", new Login());
        return "login";
    }
}
