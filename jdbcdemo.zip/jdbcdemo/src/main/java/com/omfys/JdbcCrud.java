package com.omfys;

public class JdbcCrud {
	public static void main(String[] args) {
		
	}
}
