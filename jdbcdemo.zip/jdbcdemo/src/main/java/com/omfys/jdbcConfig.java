package com.omfys;


public class jdbcConfig {


}
